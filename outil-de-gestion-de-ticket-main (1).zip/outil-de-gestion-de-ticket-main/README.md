# outil-de-gestion-de-ticket
Objectif : Créer une base de données et un gestionnaire de ticket, afin de pouvoir déterminer l’état des missions, et pouvoir les modifiers.

Vous trouverez ci-dessous un fichier avec tous le projet et une vidéo montrant le mode de fonctionnement du projet.
